#
# Copyright Amazon AWS DeepLens, 2017
#
import os
import greengrasssdk
from threading import Timer
import time
import awscam
import cv2
import mxnet as mx
from threading import Thread

ret, frame = awscam.getLastFrame()
ret,jpeg = cv2.imencode('.jpg', frame) 
Write_To_FIFO = True
class FIFO_Thread(Thread):
    def __init__(self):
        ''' Constructor. '''
        Thread.__init__(self)
 
    def run(self):
        fifo_path = "/tmp/results.mjpeg"
        if not os.path.exists(fifo_path):
            os.mkfifo(fifo_path)
        f = open(fifo_path,'w')
        client.publish(topic=iotTopic, payload="Opened Pipe")
        while Write_To_FIFO:
            try:
                f.write(jpeg.tobytes())
            except IOError as e:
                continue  


# Creating a greengrass core sdk client
client = greengrasssdk.client('iot-data')

# The information exchanged between IoT and clould has 
# a topic and a message body.
# This is the topic that this code uses to send messages to cloud
iotTopic = '$aws/things/{}/infer'.format(os.environ['AWS_IOT_THING_NAME'])

# When deployed to a Greengrass core, this code will be executed immediately
# as a long-lived lambda function.

def greengrass_infinite_infer_run():
    try:
        artifact_file = "/opt/awscam/artifacts/mxnet_squeezenet.xml"
        modelType = "classification"
        results_thread = FIFO_Thread()
        results_thread.start()

        # Send a starting message to IoT console
        client.publish(topic=iotTopic, payload="helmet or not inference starts now")

        # Load model to GPU (use {"GPU": 0} for CPU)
        mcfg = {"GPU": 1}
        model = awscam.Model(artifact_file, mcfg)
        client.publish(topic=iotTopic, payload="Model loaded")
        ret, frame = awscam.getLastFrame()
        width = frame.shape[1]
        if ret == False:
            raise Exception("Failed to get frame from the stream")

        numFrames = 0;
        doInfer = True
        while doInfer:
            # Get a frame from the video stream
            ret, frame = awscam.getLastFrame()

            # Raise an exception if failing to get a frame
            if ret == False:
                raise Exception("Failed to get frame from the stream")

            # Resize frame to fit model input requirement
            frameResize = cv2.resize(frame, (224, 224))

            # Run model inference on the resized frame
            inferOutput = model.doInference(frameResize)

            outputProcessed = model.parseResult(modelType, inferOutput)
            results = outputProcessed[modelType]
            prob_helmet = 0
            for obj in results:
                if obj['label'] == 778: # MXNet index for crash helmet
                    prob_helmet = obj['prob']
                    break
            prob_not_helmet = 1.0 - prob_helmet
            
            cv2.rectangle(frame, (0,0), (int(width*prob_not_helmet), 30), (0, 0, 255), -1)
            cv2.rectangle(frame, (0,30), (int(width*prob_helmet), 60), (255, 0, 0), -1)
            
            font = cv2.FONT_HERSHEY_SIMPLEX
            cv2.putText(frame, 'Not helmet', (0,22), font, 1, (225, 225, 225), 1)
            cv2.putText(frame, 'helmet', (0,52), font, 1, (225, 225, 225), 1)
            
            msg = '{{"helmet": {}, "Not helmet": {}}}'.format(str(prob_helmet), str(prob_not_helmet))
            client.publish(topic=iotTopic, payload=msg)
            global jpeg
            ret,jpeg = cv2.imencode('.jpg', frame)
            
    except Exception as e:
        msg = "Test failed: " + str(e)
        client.publish(topic=iotTopic, payload=msg)

    # Asynchronously schedule this function to be run again in 15 seconds
    Timer(15, greengrass_infinite_infer_run).start()


# Execute the function above
greengrass_infinite_infer_run()


# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
    return